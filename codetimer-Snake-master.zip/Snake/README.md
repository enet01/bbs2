# Python(pygame) 贪吃蛇

100行代码的贪吃蛇

![image](https://raw.githubusercontent.com/codetask/Snake-/master/1.png)
![image](https://raw.githubusercontent.com/codetask/Snake-/master/2.png)
